require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const User = require('./models/User');
const Counter = require('./models/Counter');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch(err => console.error('MongoDB connection error:', err));

// Function to get and increment the ID counter
async function getNextSequenceValue(name) {
  const counter = await Counter.findOneAndUpdate(
    { name },
    { $inc: { count: 1 } },
    { new: true, upsert: true }
  );
  return counter.count;
}

// POST - Create new user with auto-increment ID
app.post('/users', async (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({ message: 'Name and email are required' });
  }

  try {
    // Get the next available ID using the counter
    const newId = await getNextSequenceValue('userId');

    const newUser = new User({ id: newId, name, email });
    await newUser.save();

    res.status(201).json({ message: 'User created', user: newUser });
  } catch (err) {
    res.status(500).json({ message: 'Error creating user', error: err.message });
  }
});

// GET - Fetch all users
app.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json({ users });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching users', error: err.message });
  }
});

// GET - Get user by ID
app.get('/users/:id', async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const user = await User.findOne({ id });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ user });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching user', error: err.message });
  }
});

// PUT - Update a user by ID
app.put('/users/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { name, email } = req.body;

  try {
    const updatedUser = await User.findOneAndUpdate({ id }, { name, email }, { new: true });
    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ message: 'User updated', user: updatedUser });
  } catch (err) {
    res.status(500).json({ message: 'Error updating user', error: err.message });
  }
});

// DELETE - Delete a user by ID
app.delete('/users/:id', async (req, res) => {
  const id = parseInt(req.params.id);

  try {
    const deletedUser = await User.findOneAndDelete({ id });
    if (!deletedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json({ message: 'User deleted', user: deletedUser });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting user', error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
