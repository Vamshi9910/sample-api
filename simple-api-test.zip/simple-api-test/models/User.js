const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  id: {
    type: Number,
    unique: true, // Ensures unique integer IDs
    required: true
  },
  name: String,
  email: String
});

module.exports = mongoose.model('User', userSchema);
